For the Poker project, I began by creating the Card class. First, I used the 
constructor in order to initalize the suit and rank of the given card. After the initial 
constructor, in later classes (such as Game), I realized I needed to overload this
constructor just in case that the input values did not match the integer type of the
original constructor. After the constructors, I made a compareTo method that would look at
the ranks of two given cards and compare them to see which is greater than another, and in
the case that they are the same, compare their ranks. The method boolean equals(Object o) 
is cited from stack overflow: https://stackoverflow.com/questions/12697407/arraylist-remove-is-not-removing-an-object
which I searched up because when I was calling the Player's method .remove() for
an object in my user's 5 cards (their hand), it was not working. I found out that it was 
because it was not recognizing the card in the list, and this method helped solve that problem.
I added my own methods to get the rank and suit of the card, as well as a String toString()
method that changes the suit and rank from the integers that they are to a string in the form
suit " of " rank (e.g. A of spades).

Next was the Deck class. In here, I created a constructor that initialized a regular deck
of size 52 with appropriate suit and rank. Then, I created a method that shuffled the deck
by ussing the Collections.shuffle() method that is built in for ArrayLists when I import java.
util.Collections. Then, I created a deal method that would track where we are in the deck in
order to avoid redealing the same card more than once. Lastly, the toString() method uses the 
Card class's toString() method and adds to it by making a list of the hand that the player will
end up having. 

The Player class is next. In this, I created a constructor where I arbitrarily assigned the 
bankroll to 100, the initial bet to 0, and the hand to an empty ArrayList. Then, I used Collections
once again in order to sort the hand according to my compareTo rules from the Card class. I 
also made a getHand() function to easily return the current hand of the player, a setBankroll
function to change the bankroll if needed, a reset method in case the player starts over with a 
new hand and new bet. Then, using ArrayList methods, the addCard and removeCard functions add and 
remove cards from the ArrayList hand, respectively. The bets(amt) function adjusts the bankroll as
needed and changes bet. Winnings() adjusts the bankroll to account for the possible winning hand 
that the player may have, getBankroll() easily returns the bankroll, and the toString() method 
prints out what the player's hand currently has. 

Lastly, the Game class. In here, I declared many final variables that are Strings because they 
allow me to easily see what winning hand the player will have. I also declared a scanner for the 
whole class so that I can easily get user input when needed. Then, I built a constructor for a test
hand that would look at the input of the player (an array) and convert it into the player's hand, 
which I used for my own use to test out my code. In the argument-less constructor, I did a similar
thing by just resetting the deck (creating a new deck and shuffling it), creating a new Player, and
giving that player 5 cards randomly (through the dealCards(int c) method). After the constructor, the 
play() method is where most things happen. I introduce the player, and created a loop for the player
to decide how long they would play. I asked how much they would want to bet by creating a private method
getBet(), and I asked how many and which cards they wanted to swap through the swapCards() method. The
game would replay if playAgain ever became false, which was tracked through the replayGame() method. 
doWinnings() had the winnings were tracked by checkHand(), which looked at every possible outcome--royal 
flush all the way down to no pair, each in their own private methods-- and returned a string for what 
hand the player had. Then, doWinnings() would check the final strings declared in the beginning and 
the string returned by checkHand() and assign the correct amount that the bankroll of the player would 
increase by. All of these working together makes the PokerTest game execute and work correctly. 